/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bai_cuoi_ky;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Collections; 
import java.util.Comparator;  

/**
 *
 * @author ASUS
 */
import java.util.ArrayList;
public class DoorList extends ArrayList<Door> {

    // Them du lieu mau
   public void themDuLieuMau() {  //5 đối tượng cửa tao sẵn 
        this.add(new Door("D001", "Go Soi", "Nau", 0.9, 2.2, false));
        this.add(new Door("D002", "Kinh", "Trong suot", 1.2, 2.4, true));
        this.add(new Door("D003", "Sat", "Xam", 0.8, 2.0, false));
        this.add(new Door("D004", "Nhom Xingfa", "Den", 1.5, 2.5, true));
        this.add(new Door("D005", "Go Cong Nghiep", "Trang", 0.9, 2.1, false));
    }

    // Hien thi tat ca danh sach
    public void hienThiTatCa() {
        System.out.println("\n" + String.format("| %-8s | %-12s | %-10s | %-8s | %-8s | %-12s |", 
                "Ma Cua", "Chat Lieu", "Mau Sac", "Rong(m)", "Cao(m)", "Loai Cua"));
        System.out.println("---------------------------------------------------------------------------");
        if (this.isEmpty()) {
            System.out.println("Danh sach dang trong!");
        } else {
            for (Door d : this) {
                System.out.println(d.toString());
            }
        }
        System.out.println("---------------------------------------------------------------------------");
    }

    // Sap xep theo Chat lieu
    public void sapXepTheoChatLieu() {
        Collections.sort(this);
        System.out.println("Da sap xep theo chat lieu.");
    }

    // Sap xep theo Chieu rong (Giam dan)
    public void sapXepTheoChieuRong() {
        this.sort(new Comparator<Door>() {
            @Override
            public int compare(Door d1, Door d2) {
                return Double.compare(d2.getChieuRong(), d1.getChieuRong());
            }
        });
        System.out.println("Da sap xep theo chieu rong giam dan.");
    }

    // Cap nhat thong tin cua
    public void capNhatCua(Scanner sc) {
        System.out.print("Nhap ma cua can sua: ");
        String id = sc.nextLine();
        for (Door d : this) {
            if (d.getMaCua().equalsIgnoreCase(id)) {
                System.out.print("Nhap chat lieu moi: ");
                d.setChatLieu(sc.nextLine());
                System.out.print("Nhap mau sac moi: ");
                d.setMauSac(sc.nextLine());
                System.out.print("Nhap chieu rong moi: ");
                d.setChieuRong(Double.parseDouble(sc.nextLine()));
                System.out.print("Nhap chieu cao moi: ");
                d.setChieuCao(Double.parseDouble(sc.nextLine()));
                System.out.print("Cua tu dong khong (true/false): ");
                d.setLaCuaTuDong(Boolean.parseBoolean(sc.nextLine()));
                System.out.println("Cap nhat thanh cong!");
                return;
            }
        }
        System.out.println("Khong tim thay cua co ma: " + id);
    }

    // Tim kiem theo Ma Cua
    public void timKiemTheoMa(Scanner sc) {
        System.out.print("Nhap ma cua can tim: ");
        String targetId = sc.nextLine();
        boolean found = false;
        for (Door d : this) {
            if (d.getMaCua().equalsIgnoreCase(targetId)) {
                System.out.println(String.format("| %-8s | %-12s | %-10s | %-8s | %-8s | %-12s |", 
                        "Ma Cua", "Chat Lieu", "Mau Sac", "Rong(m)", "Cao(m)", "Loai Cua"));
                System.out.println(d.toString());
                found = true;
                break;
            }
        }
        if (!found) System.out.println("Khong tim thay cua co ma: " + targetId);
    }

    // Them cua moi
    public void themCuaMoi(Scanner sc) {
        System.out.println("--- NHAP THONG TIN CUA MOI ---");
        String id;
        while (true) {
            System.out.print("Nhap ma cua moi: ");
            id = sc.nextLine();
            boolean isDuplicate = false;
            for (Door d : this) {
                if (d.getMaCua().equalsIgnoreCase(id)) {
                    isDuplicate = true;
                    break;
                }
            }
            if (!isDuplicate) break;
            System.out.println("Ma cua nay da ton tai!");
        }

        System.out.print("Nhap chat lieu: ");
        String material = sc.nextLine();
        System.out.print("Nhap mau sac: ");
        String color = sc.nextLine();
        System.out.print("Nhap chieu rong (m): ");
        double width = Double.parseDouble(sc.nextLine());
        System.out.print("Nhap chieu cao (m): ");
        double height = Double.parseDouble(sc.nextLine());
        System.out.print("Cua tu dong? (true/false): ");
        boolean automatic = Boolean.parseBoolean(sc.nextLine());

        this.add(new Door(id, material, color, width, height, automatic));
        System.out.println("Da them thanh cong!");
    }

    // Xoa cua
    public void xoaCua(Scanner sc) {
        System.out.print("Nhap ma cua can xoa: ");
        String id = sc.nextLine();
        int index = -1;
        for (int i = 0; i < this.size(); i++) {
            if (this.get(i).getMaCua().equalsIgnoreCase(id)) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            this.remove(index);
            System.out.println("Xoa thanh cong cua ma: " + id);
        } else {
            System.out.println("Khong tim thay ma cua: " + id);
        }
    }
}