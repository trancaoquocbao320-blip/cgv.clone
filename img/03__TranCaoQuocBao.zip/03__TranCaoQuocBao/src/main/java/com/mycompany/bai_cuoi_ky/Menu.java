/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bai_cuoi_ky;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Menu {
    private String tieuDe;
    private ArrayList<String> danhSachLuaChon;
    private Scanner sc = new Scanner(System.in);

    public Menu(String tieuDe) {
        this.tieuDe = tieuDe;
        this.danhSachLuaChon = new ArrayList<>();
    }

    // Them muc vao menu
    public void addItem(String item) {
        danhSachLuaChon.add(item);
    }

    // Hien thi menu ra man hinh
    public void display() {
        System.out.println("\n=============================================");
        System.out.println("   " + tieuDe.toUpperCase());
        System.out.println("=============================================");
        for (int i = 0; i < danhSachLuaChon.size(); i++) {
            System.out.println((i + 1) + ". " + danhSachLuaChon.get(i));
        }
        System.out.println("=============================================");
    }

    // Lay lua chon 
    public int getChoice() {
        display();
        System.out.print("Lua chon cua ban (1-" + danhSachLuaChon.size() + "): ");
        try {
            String input = sc.nextLine();
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            System.out.println("Loi: Vui long nhap mot so nguyen!");
            return -1; 
        }
    }
}