/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bai_cuoi_ky;

import java.util.ArrayList;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

public class Program {
    public static void main(String[] args) {
        //  Khoi tao doi tuong Scanner de dung chung cho toan bo chuong trinh
        Scanner sc = new Scanner(System.in);
        
        //  tao danh sach quan ly cua
        DoorList danhSach = new DoorList();
        
        // Them du lieu mau de chay thu
        danhSach.themDuLieuMau();
        
        //   tao Menu 
        Menu menu = new Menu("HE THONG QUAN LY CUA (DOOR MANAGEMENT)");
        
        menu.addItem("Hien thi danh sach cua (khong sap xep)");
        menu.addItem("Sap xep danh sach theo CHAT LIEU");
        menu.addItem("Sap xep theo CHIEU RONG (Giam dan)");
        menu.addItem("Them cua moi");
        menu.addItem("Cap nhat thong tin cua");
        menu.addItem("Xoa mot cua");
        menu.addItem("Tim kiem cua theo ma");
        menu.addItem("Nhap danh sach tu file");
        menu.addItem("Xuat danh sach ra file");
        menu.addItem("Thoat");

        int luaChon;
        do {
            luaChon = menu.getChoice();
            switch (luaChon) {
                case 1 -> danhSach.hienThiTatCa();
                case 2 -> { 
                    danhSach.sapXepTheoChatLieu(); 
                    danhSach.hienThiTatCa(); 
                }
                case 3 -> { 
                    danhSach.sapXepTheoChieuRong(); 
                    danhSach.hienThiTatCa(); 
                }
                case 4 -> danhSach.themCuaMoi(sc);
                case 5 -> danhSach.capNhatCua(sc);
                case 6 -> danhSach.xoaCua(sc);
                case 7 -> danhSach.timKiemTheoMa(sc);
                case 8 -> {
                    // Neu ban da viet ham docTuFile thi bo dau // o duoi
                    // danhSach.docTuFile("Cua.txt"); 
                }
                case 9 -> {
                    // Tương tu ham ghiRaFile
                    // danhSach.ghiRaFile("danh_sach_cua_xuat.txt");
                }
                case 10 -> System.out.println("Cam on ban da su dung chuong trinh! Tam biet!!!");
                default -> System.out.println("Lua chon khong hop le.");
            }
        } while (luaChon != 10);
    }
}