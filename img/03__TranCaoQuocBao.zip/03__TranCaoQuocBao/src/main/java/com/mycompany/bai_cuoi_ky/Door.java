/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai_cuoi_ky;

/**
 *
 * @author ASUS
 */


import java.util.Scanner;

public class Door implements Comparable<Door> {
    private String maCua;      // ID
    private String chatLieu;   // Material
    private String mauSac;     // Color
    private double chieuRong;  // Width
    private double chieuCao;   // Height
    private boolean laCuaTuDong; // Is Automatic

    public Door() {
    }

    public Door(String maCua, String chatLieu, String mauSac, double chieuRong, double chieuCao, boolean laCuaTuDong) {
        this.maCua = maCua;
        this.chatLieu = chatLieu;
        this.mauSac = mauSac;
        this.chieuRong = chieuRong;
        this.chieuCao = chieuCao;
        this.laCuaTuDong = laCuaTuDong;
    }

    // Them getter setter
    public String getMaCua() { return maCua; }
    public void setMaCua(String maCua) { this.maCua = maCua; }

    public String getChatLieu() { return chatLieu; }
    public void setChatLieu(String chatLieu) { this.chatLieu = chatLieu; }

    public String getMauSac() { return mauSac; }
    public void setMauSac(String mauSac) { this.mauSac = mauSac; }

    public double getChieuRong() { return chieuRong; }
    public void setChieuRong(double chieuRong) { this.chieuRong = chieuRong; }

    public double getChieuCao() { return chieuCao; }
    public void setChieuCao(double chieuCao) { this.chieuCao = chieuCao; }

    public boolean isLaCuaTuDong() { return laCuaTuDong; }
    public void setLaCuaTuDong(boolean laCuaTuDong) { this.laCuaTuDong = laCuaTuDong; }

    // giao dien nhap du lieu
    public void nhap() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap ma cua: "); this.maCua = sc.nextLine();
        System.out.print("Nhap chat lieu: "); this.chatLieu = sc.nextLine();
        System.out.print("Nhap mau sac: "); this.mauSac = sc.nextLine();
        System.out.print("Nhap chieu rong (m): "); this.chieuRong = Double.parseDouble(sc.nextLine());
        System.out.print("Nhap chieu cao (m): "); this.chieuCao = Double.parseDouble(sc.nextLine());
        System.out.print("Cua tu dong? (true/false): "); this.laCuaTuDong = Boolean.parseBoolean(sc.nextLine());
    }

    @Override
    public int compareTo(Door khac) {
        // Sap xep mac dinh theo Chat lieu
        return this.chatLieu.compareToIgnoreCase(khac.chatLieu);
    }

    @Override
    public String toString() {
        
        return String.format("| %-8s | %-12s | %-10s | %-8.2f | %-8.2f | %-12s |", 
                maCua, chatLieu, mauSac, chieuRong, chieuCao, (laCuaTuDong ? "Tu dong" : "Thu cong"));
    }

    //  ho tro xuat du lieu ra file 
    public String toFileString() {
        return maCua + "," + chatLieu + "," + mauSac + "," + chieuRong + "," + chieuCao + "," + laCuaTuDong;
    }
}